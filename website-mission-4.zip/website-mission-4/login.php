<?php 
include 'service/database.php';
session_start();

if (isset($_SESSION['is_logged_in']) && $_SESSION['is_logged_in'] === true) {
    header("Location: dashboard.php");
    exit;
}

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $result = $db->query($sql);

    if ($result->num_rows > 0) {
       $data = $result->fetch_assoc();
       $_SESSION['name'] = $data['name'];
       $_SESSION['role'] = $data['role'];
       $_SESSION['username'] = $username;
       $_SESSION['is_logged_in'] = true;
       header("Location: dashboard.php");
       exit;
    } else {
        echo "<script>alert('Login Failed: Invalid username or password');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login - Todo App</title>
    <link rel="stylesheet" href="style.css" />
    <style>
      html,body { height: 100%; margin: 0; }
      body {
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen,
          Ubuntu, Cantarell, "Open Sans", "Helvetica Neue", sans-serif;

        /* 🌄 Background image setup */
        background: url("https://4kwallpapers.com/images/walls/thumbs_3t/24150.jpg") no-repeat center center fixed;
        background-size: cover;
        color: #111827;
      }

      /* Desktop popup */
      .login-modal {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%) scale(0.9);
        background: #fff;
        border-radius: 20px;
        padding: 2rem;
        width: 90%;
        max-width: 400px;
        z-index: 1001;
        box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        opacity: 0;
        animation: popup 0.28s cubic-bezier(.2,.9,.2,1) forwards;
      }
      .black-backdrop {
        position: fixed;
        top: 0; left: 0;
        width: 100%; height: 100%;
        background: rgba(0,0,0,0.45);
        z-index: 1000;
      }
      @keyframes popup {
        to {
          transform: translate(-50%, -50%) scale(1);
          opacity: 1;
        }
      }

      .login-modal h1 { text-align: center; margin: 0 0 0.6rem; font-size: 1.4rem; }
      .login-modal p.helper { text-align:center; margin:0 0 1rem; color:#666; }

      .login-modal .input-group { margin-bottom: 0.9rem; }
      .login-modal label { display:block; margin-bottom:0.35rem; color:#333; font-weight:600; font-size:0.9rem; }
      .login-modal input {
        width: 100%;
        padding: 0.9rem;
        border-radius: 12px;
        border: 1px solid #e5e7eb;
        outline: none;
        font-size: 1rem;
      }
      .login-modal input:focus { box-shadow: 0 0 0 4px rgba(79,70,229,0.08); border-color: #4f46e5; }

      .login-modal button {
        width: 100%;
        padding: 0.95rem;
        border: none;
        border-radius: 12px;
        background: #4f46e5;
        color: white;
        font-weight: 700;
        cursor: pointer;
        font-size: 1rem;
        transition: transform .12s ease, background .12s ease;
      }
      .login-modal button:active { transform: scale(.98); }
      .login-modal .small { margin-top:0.8rem; text-align:center; font-size:0.9rem; color:#444; }

      /* 📱 Mobile full screen mode */
      @media (max-width: 768px) {
        body {
          background: url("https://4kwallpapers.com/images/walls/thumbs_3t/24150.jpg") no-repeat center center fixed;
          background-size: cover;
        }
        .login-modal {
          top: 0;
          left: 0;
          transform: none !important;
          width: 100%;
          height: 100vh;
          max-width: none;
          border-radius: 0;
          animation: none;
          display: flex;
          flex-direction: column;
          justify-content: center;
          opacity: 0.9 !important;
          z-index: 2000 !important;
          padding: env(safe-area-inset-top, 20px) 20px 28px;
          overflow-y: auto;
          -webkit-overflow-scrolling: touch;

          /* 🔥 Transparent overlay on mobile */
          background: rgba(255, 255, 255, 0.88);
          backdrop-filter: blur(6px);
        }
        .black-backdrop { display: none; }

        .login-modal input { padding: 1rem; font-size: 1.03rem; }
        .login-modal button { padding: 1.05rem; font-size: 1.05rem; border-radius: 10px; }
      }

      .login-form-wrap { max-width: 420px; margin: 0 auto; width:100%; }
    </style>
  </head>
  <body>
    <div class="black-backdrop" aria-hidden="true"></div>

    <div class="login-modal" role="dialog" aria-labelledby="login-title">
      <div class="login-form-wrap">
        <h1 id="login-title">Welcome Back 👋</h1>
        <p class="helper">Please login to continue</p>

        <form action="login.php" method="POST" novalidate>
          <div class="input-group">
            <label for="username">Email</label>
            <input type="email" id="username" name="username" required />
          </div>
          <div class="input-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required />
          </div>  
          <button type="submit" name="login">Login</button>
        </form>

        <p class="small">
          Don’t have an account?
          <a href="register.php" style="color:#4f46e5; font-weight:700; text-decoration:none;">Register</a>
        </p>
      </div>
    </div>
  </body>
</html>
