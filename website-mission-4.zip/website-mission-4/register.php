<?php
include 'service/database.php';
session_start();

// If already logged in, go to dashboard
if (isset($_SESSION['is_logged_in']) && $_SESSION['is_logged_in'] === true) {
    header("Location: dashboard.php");
    exit;
}

if (isset($_POST['register'])) {
    $fullname = trim($_POST['fullname']);
    $role     = trim($_POST['role']);
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Basic validation
    if ($fullname === '' || $role === '' || $username === '' || $password === '') {
        echo "<script>alert('Please fill all fields');</script>";
    } else {
        // Check existing account (prepared statement)
        $check_stmt = mysqli_prepare($db, "SELECT id FROM users WHERE username = ?");
        mysqli_stmt_bind_param($check_stmt, "s", $username);
        mysqli_stmt_execute($check_stmt);
        mysqli_stmt_store_result($check_stmt);

        if (mysqli_stmt_num_rows($check_stmt) > 0) {
            echo "<script>alert('Account already exists!');</script>";
            mysqli_stmt_close($check_stmt);
        } else {
            mysqli_stmt_close($check_stmt);

            // Insert new user (prepared statement)
            $insert_stmt = mysqli_prepare($db, "INSERT INTO users (username, password, name, role) VALUES (?, ?, ?, ?)");
            mysqli_stmt_bind_param($insert_stmt, "ssss", $username, $password, $fullname, $role);
            $ok = mysqli_stmt_execute($insert_stmt);

            if ($ok && mysqli_stmt_affected_rows($insert_stmt) > 0) {
                mysqli_stmt_close($insert_stmt);
                echo "<script>alert('Registration Successful'); window.location.href='login.php';</script>";
                exit;
            } else {
                mysqli_stmt_close($insert_stmt);
                echo "<script>alert('Registration Failed');</script>";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>yvdzke - Register</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <style>
      html, body { height: 100%; margin: 0; font-family: Inter, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial; }

      /* 🌄 Background image */
      body {
        background: url("https://4kwallpapers.com/images/walls/thumbs_3t/24150.jpg") no-repeat center center fixed;
        background-size: cover;
      }

      /* Modal (desktop popup) */
      .auth-modal {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%) scale(0.92);
        background: #fff;
        border-radius: 18px;
        padding: 2rem;
        width: 92%;
        max-width: 420px;
        z-index: 1001;
        box-shadow: 0 12px 30px rgba(2,6,23,0.18);
        opacity: 0;
        animation: popup 0.28s cubic-bezier(.2,.9,.2,1) forwards;
      }

      .black-backdrop {
        position: fixed;
        top: 0; left: 0;
        width: 100%; height: 100%;
        background: rgba(0,0,0,0.45);
        z-index: 1000;
      }

      @keyframes popup {
        to { transform: translate(-50%, -50%) scale(1); opacity: 1; }
      }

      .auth-modal h1 { text-align: center; margin: 0 0 0.6rem; font-size: 1.4rem; }
      .auth-modal p.helper { text-align:center; margin:0 0 1rem; color:#6b7280; }

      .input-group { margin-bottom: 0.9rem; }
      label { display:block; margin-bottom:0.35rem; color:#333; font-weight:600; font-size:0.92rem; }
      input[type="text"], input[type="email"], input[type="password"], select {
        width:100%;
        padding: .85rem;
        border-radius: 12px;
        border: 1px solid #e6e9ee;
        font-size: 1rem;
        outline: none;
      }
      input:focus, select:focus { box-shadow: 0 0 0 6px rgba(79,70,229,0.06); border-color: #4f46e5; }

      .btn {
        width:100%;
        padding:.95rem;
        border-radius: 12px;
        border: none;
        background:#4f46e5;
        color:#fff;
        font-weight:700;
        cursor:pointer;
        font-size:1rem;
        transition: transform .12s ease, background .12s;
      }
      .btn:active { transform: scale(.985); }

      .small { margin-top:.9rem; text-align:center; font-size:.92rem; color:#444; }

      /* 📱 Mobile: fullscreen translucent modal */
      @media (max-width: 768px) {
        .auth-modal {
          top: 0;
          left: 0;
          transform: none !important;
          width: 100%;
          height: 100vh;
          max-width: none;
          border-radius: 0;
          animation: none;
          box-shadow: none;
          display: flex;
          flex-direction: column;
          justify-content: center;
          opacity: 0.9 !important;
          z-index: 2000 !important;
          padding: env(safe-area-inset-top, 22px) 20px 28px;
          overflow-y: auto;
          -webkit-overflow-scrolling: touch;

          /* 🌫️ translucent effect to see bg image */
          background: rgba(255,255,255,0.88);
          backdrop-filter: blur(10px);
        }
        .black-backdrop { display:none; }
        input[type="text"], input[type="email"], input[type="password"], select { padding: 1rem; font-size: 1.03rem; }
        .btn { padding: 1.05rem; font-size: 1.05rem; border-radius: 10px; }
      }

      .form-wrap { max-width: 460px; margin: 0 auto; width:100%; }
    </style>
  </head>
  <body>
    <!-- backdrop (hidden on mobile fullscreen) -->
    <div class="black-backdrop" aria-hidden="true"></div>

    <div class="auth-modal" role="dialog" aria-labelledby="register-title">
      <div class="form-wrap">
        <h1 id="register-title">Create Account ✨</h1>
        <p class="helper">Fill in the details to create your account</p>

        <form action="register.php" method="post" novalidate>
          <div class="input-group">
            <label for="fullname">Full Name</label>
            <input type="text" id="fullname" name="fullname" required />
          </div>

          <div class="input-group">
            <label for="role">Role</label>
            <input type="text" id="role" name="role" required />
          </div>

          <div class="input-group">
            <label for="username">Email</label>
            <input type="email" id="username" name="username" required />
          </div>

          <div class="input-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required />
          </div>

          <button class="btn" type="submit" name="register">Register</button>
        </form>

        <p class="small">
          Already have an account?
          <a href="login.php" style="color:#4f46e5; font-weight:700; text-decoration:none;">Login</a>
        </p>
      </div>
    </div>
  </body>
</html>
